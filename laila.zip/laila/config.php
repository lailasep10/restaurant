<?php

// tb_user,tb_menu
$connection = mysqli_connect('localhost','root','','project_pbo_premium');

?>