<?php 

include "../config.php";
session_start();
$id = $_GET["id_user"];
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

function delete($user)
{
    global $connection;
    
    mysqli_query($connection,"DELETE FROM tb_user WHERE id_user = $user");
    return mysqli_affected_rows($connection);
}

if(delete($id) > 0)
{
    echo "
    <script>
        document.location.href = './index.php'
    </script>
    ";
}

?>