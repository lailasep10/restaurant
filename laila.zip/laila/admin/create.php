<?php

include "../config.php";
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

function create($data)
{
    global $connection;

    $name = $data["username"];
    $password = $data["password"];
    $level = $data["level"];

    if($data["level"] == "")
    {
        echo "
        <script>
            alert('harap isi status level')
        </script>
        ";
        return false;
    }
    mysqli_query($connection, "INSERT INTO tb_user VALUES(
        '',
        '$name',
        '$password',
        '$level'
    )");

    return mysqli_affected_rows($connection);
}

if (isset($_POST["submit"])) {
    if (create($_POST) > 0) {
        header('location: index.php');
        echo "
        <script>
            alert('data berhasil di tambahkan')
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="w-full flex flex-col justify-center items-center select-none">
    <nav class="w-full h-16 mb-8 bg-pink-700 flex justify-between items-center px-5">
        <div class="text-white">
            <a href="index.php" class="font-bold text-lg mr-4 hover:underline hover:underline-offset-8">Home</a>
            <a href="../menu/index.php" class="font-bold text-lg font-sans hover:underline hover:underline-offset-8">Menu</a>
        </div>
        <div>
            <a href="../auth/logout.php" onclick="return confirm('yakin ingin logout?')" class="font-bold text-lg font-sans hover:underline hover:underline-offset-8 text-white">Logout</a>
        </div>
    </nav>
    <div class="flex justify-center items-center w-full h-full">
        <form method="post" action="" class="w-1/2 h-full border border-pink-300 rounded-lg flex flex-col justify-center items-center py-12 mt-5 bg-pink-600">
            <div class="w-full flex justify-center items-center my-2">
                <input type="text" name="username" placeholder="Username" class="w-1/2 py-2 px-4 font-semibold text-lg focus:outline-none rounded-lg">
            </div>
            <div class="w-full flex justify-center items-center my-2">
                <input type="password" name="password" placeholder="Password" class="w-1/2 py-2 px-4 font-semibold text-lg focus:outline-none rounded-lg">
            </div>
            <div class="w-full flex justify-center items-center my-2">
                <select name="level" id="" class="w-1/2 py-2 px-4 outline-none font-semibold text-lg rounded-lg">
                    <option value="">-pilih level-</option>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>
            </div>
            <div class="w-1/2 flex justify-end items-center mb-2 mt-5">
                <button type="submit" name="submit" class="py-2 px-4 mr-4 bg-pink-500 outline-white outline font-semibold text-lg rounded-lg text-white">Submit</button>
                <a href="index.php" class="py-2 px-4 outline outline-white duration-300 font-semibold text-lg rounded-lg text-white">Back</a>
            </div>
        </form>
    </div>
</body>
</html>