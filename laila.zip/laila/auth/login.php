<?php

include "../config.php";
session_start();

if(isset($_POST["submit"]))
{
    // fetch data input from form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // filter data
    $filter = mysqli_query($connection,"SELECT * FROM tb_user where username = '$username' and password = '$password' ");
    $user = mysqli_fetch_assoc($filter);

    // conditional
    if(mysqli_num_rows($filter) === 1)
    {
        if($user["level"] == "admin")
        {
            $_SESSION["admin"] = $username;
            echo "
            <script>
                document.location.href = '../admin/index.php'
            </script>
            ";
        }else if($user["level"] == "user")
        {
            $_SESSION["user"] = $username;
            $_SESSION["id_user"] = $user["id_user"];
            echo "
            <script>
                document.location.href = '../user/index.php'
            </script>
            ";

        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>
<body class="bg-pink-600">
    <div class="w-full h-screen flex justify-center items-center">
        <form action="" method="post" class="bg-pink-400 flex justify-center items-center flex-col w-1/3 h-2/5 rounded">
            <div class="w-full flex justify-center items-center mb-2">
                <span class="font-bold text-white text-3xl">Login</span>
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="text" name="username" placeholder="Username" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-gray-700 focus:outline-none ">
            </div>
            <div class="w-full flex justify-center items-center mb-2">
                <input type="password" name="password" placeholder="Password" class="w-2/3 py-2 px-4 rounded font-semibold text-lg text-gray-700 focus:outline-none ">
            </div>
            <div class="flex justify-center w-full items-center mt-4">
                <button type="submit" name="submit" class="bg-pink-600 outline outline-white py-2 px-6 font-semibold text-lg rounded text-white">Submit</button>
                <div class="mx-1"></div>
                <a href="../index.php" class="bg-red-500 py-2 px-6 outline outline-white font-semibold text-lg rounded text-white">Back</a>
            </div>
        </form>
    </div>
</body>
</html>