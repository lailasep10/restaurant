<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./dist/output.css">
</head>
<body class="w-full h-full flex flex-col">
    <nav class="flex justify-end items-end py-4 px-8 bg-pink-600">    
        <a href="./auth/login.php" class="text-xl text-white font-bold font-sans hover:text-gray-500 duration-300">Login</a>
    </nav>
    <div class="flex flex-col w-full h-full bg-pink-200 justify-center items-center pb-20">
        <div class="w-full justify-center items-center flex py-20 flex-col">
            <span class="py-10 bg-pink-400 rounded text-white text-xl font-bold w-2/5 text-center">DIKLA RESTO</span>
            <a href="./user/index.php" class="py-2 px-4 mt-4 bg-pink-600 font-bold text-xl text-white rounded">Pesan Sekarang</a>
        </div>
        <div class="w-full h-full flex flex-row bg-pink-400">
            <div class="w-1/2 p-8">
                <img src="./img/ice1.jpeg" class="rounded">
            </div>
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-pink-600 rounded">
                    Es krim sangat cocok dinikmati saat kondisi cuaca panas atau siang hari. Rasanya yang dingin mampu menyegarkan dan memberikan rasa manis di mulut.
                    Mengonsumsi es krim juga sangat baik dalam mengembalikan mood yang buruk. Tak jarang rutinitas kerja membuat kinerja menurun, maka makan es krim kala istirahat bisa menjadi solusi.
                </span>
            </div>
        </div>
        <div class="w-full h-full flex flex-row">
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-pink-600 rounded text-center">
                Hadir dengan menyediakan varian ice crim dan cake  yang unik dan menarik, membuat DIKLA berhasil mengangkat banyak konsumen.
“Ngemil cake memang yang paling asyik. Apalagi bisa ngemil sama teman-teman tersayang. Hangout dan santai bisa makin seru. Cuma ice crim dan cake dari DIKLA  yang bisa bikin suasana makin happy. Hanya di DIKLA Rasanya bikin nagih!”
                </span>
            </div>
            <div class="w-1/2 p-8">
                <img src="./img/cake2.jpeg" class="rounded">
            </div>
        </div>
        <div class="w-full h-full flex flex-row">
            <div class="w-1/2 p-8">
                <img src="./img/icecake3.jpeg" class="rounded">
            </div>
            <div class="w-1/2 p-8 flex justify-center items-center">
                <span class="p-4 bg-white text-xl font-semibold text-pink-600 rounded text-center">              
                    Berada di kalimantan barat, restoran bernama DIKLA ini bisa memberikan pengalaman bersantap mewah dengan nuansa interior anggun dan berkelas. Sangat pas deh restoran ini untuk merayakan momen spesial seperti ulang tahun, anniv, hingga valentine di Kalimantan Barat.
                </span>
            </div>
        </div>
    </div>
</body>
</html>